from pathlib import Path

AGENT_CACHE_DIR = Path(__file__).parent / "cache" / "agents"
MESSAGES_CACHE_DIR = Path(__file__).parent / "cache" / "messages"
